<?php
$id_telegram = "6485002123";
$id_botTele  = "7473213872:AAHeOSQYbkJ7W8r3Vn92Pz9bp2lf2rPYlng";
?>
